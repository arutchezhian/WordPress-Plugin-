<?php
/*
Plugin Name: Custom Profile Cards
Description: A plugin to create and manage multiple customizable profile cards.
Version: 1.0.0
Author: Arutchezhian
*/

// Register Custom Post Type for Profile Cards
function cpc_register_profile_card() {
    $labels = array(
        'name'               => 'Profile Cards',
        'singular_name'      => 'Profile Card',
        'menu_name'          => 'Profile Cards',
        'name_admin_bar'     => 'Profile Card',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Profile Card',
        'new_item'           => 'New Profile Card',
        'edit_item'          => 'Edit Profile Card',
        'view_item'          => 'View Profile Card',
        'all_items'          => 'All Profile Cards',
        'search_items'       => 'Search Profile Cards',
        'parent_item_colon'  => 'Parent Profile Cards:',
        'not_found'          => 'No profile cards found.',
        'not_found_in_trash' => 'No profile cards found in Trash.',
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'profile-card' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title' ),
        'menu_icon'          => 'dashicons-id-alt',
    );

    register_post_type( 'profile_card', $args );
}
add_action( 'init', 'cpc_register_profile_card' );

// Add Meta Boxes for Customization
function cpc_add_custom_meta_boxes() {
    add_meta_box(
        'cpc_profile_card_meta',
        'Profile Card Details',
        'cpc_profile_card_meta_callback',
        'profile_card',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'cpc_add_custom_meta_boxes' );

function cpc_profile_card_meta_callback( $post ) {
    // Nonce field for security
    wp_nonce_field( 'cpc_save_profile_card_meta', 'cpc_profile_card_meta_nonce' );

    // Get the current values, if they exist
    $image = get_post_meta( $post->ID, '_cpc_image', true );
    $color = get_post_meta( $post->ID, '_cpc_color', true );
    $name = get_post_meta( $post->ID, '_cpc_name', true );
    $role = get_post_meta( $post->ID, '_cpc_role', true );
    $email = get_post_meta( $post->ID, '_cpc_email', true );
    $bio = get_post_meta( $post->ID, '_cpc_bio', true );
    $linkedin = get_post_meta( $post->ID, '_cpc_linkedin', true );
    $facebook = get_post_meta( $post->ID, '_cpc_facebook', true );
    $instagram = get_post_meta( $post->ID, '_cpc_instagram', true );

    ?>
    <p>
        <label for="cpc_image">Profile Image URL:</label>
        <input type="text" id="cpc_image" name="cpc_image" value="<?php echo esc_attr( $image ); ?>" size="25" />
        <button class="button cpc-upload-image">Upload Image</button>
    </p>
    <p>
        <label for="cpc_color">Card Background Color:</label>
        <input type="color" id="cpc_color" name="cpc_color" value="<?php echo esc_attr( $color ); ?>" />
    </p>
    <p>
        <label for="cpc_name">Name:</label>
        <input type="text" id="cpc_name" name="cpc_name" value="<?php echo esc_attr( $name ); ?>" size="25" />
    </p>
    <p>
        <label for="cpc_role">Role:</label>
        <input type="text" id="cpc_role" name="cpc_role" value="<?php echo esc_attr( $role ); ?>" size="25" />
    </p>
    <p>
        <label for="cpc_email">Email:</label>
        <input type="email" id="cpc_email" name="cpc_email" value="<?php echo esc_attr( $email ); ?>" size="25" />
    </p>
    <p>
        <label for="cpc_bio">Bio:</label>
        <textarea id="cpc_bio" name="cpc_bio" rows="4" cols="50"><?php echo esc_textarea( $bio ); ?></textarea>
    </p>
    <p>
        <label for="cpc_linkedin">LinkedIn URL:</label>
        <input type="url" id="cpc_linkedin" name="cpc_linkedin" value="<?php echo esc_attr( $linkedin ); ?>" size="25" />
    </p>
    <p>
        <label for="cpc_facebook">Facebook URL:</label>
        <input type="url" id="cpc_facebook" name="cpc_facebook" value="<?php echo esc_attr( $facebook ); ?>" size="25" />
    </p>
    <p>
        <label for="cpc_instagram">Instagram URL:</label>
        <input type="url" id="cpc_instagram" name="cpc_instagram" value="<?php echo esc_attr( $instagram ); ?>" size="25" />
    </p>
    <?php
}

function cpc_save_profile_card_meta( $post_id ) {
    if ( ! isset( $_POST['cpc_profile_card_meta_nonce'] ) ) {
        return;
    }

    if ( ! wp_verify_nonce( $_POST['cpc_profile_card_meta_nonce'], 'cpc_save_profile_card_meta' ) ) {
        return;
    }

    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $fields = [
        'cpc_image',
        'cpc_color',
        'cpc_name',
        'cpc_role',
        'cpc_email',
        'cpc_bio',
        'cpc_linkedin',
        'cpc_facebook',
        'cpc_instagram',
    ];

    foreach ( $fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, '_' . $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }
}
add_action( 'save_post', 'cpc_save_profile_card_meta' );

// Shortcode to Display Profile Cards
function cpc_display_profile_card( $atts ) {
    $atts = shortcode_atts(
        array(
            'id' => '',
        ),
        $atts,
        'profile_card'
    );

    if ( empty( $atts['id'] ) ) {
        return '';
    }

    $post_id = $atts['id'];

    $image = get_post_meta( $post_id, '_cpc_image', true );
    $color = get_post_meta( $post_id, '_cpc_color', true );
    $name = get_post_meta( $post_id, '_cpc_name', true );
    $role = get_post_meta( $post_id, '_cpc_role', true );
    $email = get_post_meta( $post_id, '_cpc_email', true );
    $bio = get_post_meta( $post_id, '_cpc_bio', true );
    $linkedin = get_post_meta( $post_id, '_cpc_linkedin', true );
    $facebook = get_post_meta( $post_id, '_cpc_facebook', true );
    $instagram = get_post_meta( $post_id, '_cpc_instagram', true );

    ob_start();
    ?>
    <aside class="profile-card" style="background-color: <?php echo esc_attr( $color ); ?>;">
        <header>
            <?php if ( $image ) : ?>
                <img src="<?php echo esc_url( $image ); ?>" alt="Avatar">
            <?php endif; ?>
            <h1><?php echo esc_html( $name ); ?></h1>
            <h2><?php echo esc_html( $role ); ?></h2>
            <h3><?php echo esc_html( $email ); ?></h3>
        </header>
        <div class="profile-bio">
            <p><?php echo esc_textarea( $bio ); ?></p>
        </div>
        <ul class="profile-social-links">
            <?php if ( $linkedin ) : ?>
                <li><a href="<?php echo esc_url( $linkedin ); ?>"><img src="<?php echo plugins_url( 'icons/linkedin.png', __FILE__ ); ?>" alt="LinkedIn"></a></li>
            <?php endif; ?>
            <?php if ( $facebook ) : ?>
                <li><a href="<?php echo esc_url( $facebook ); ?>"><img src="<?php echo plugins_url( 'icons/facebook.png', __FILE__ ); ?>" alt="Facebook"></a></li>
            <?php endif; ?>
            <?php if ( $instagram ) : ?>
                <li><a href="<?php echo esc_url( $instagram ); ?>"><img src="<?php echo plugins_url( 'icons/instagram.png', __FILE__ ); ?>" alt="Instagram"></a></li>
            <?php endif; ?>
        </ul>
    </aside>
    <?php
    return ob_get_clean();
}
add_shortcode( 'profile_card', 'cpc_display_profile_card' );

// Enqueue Styles and Scripts
function cpc_enqueue_admin_assets() {
    wp_enqueue_media();
    wp_enqueue_script( 'cpc-admin-js', plugins_url( 'script.js', __FILE__ ), array( 'jquery' ), null, true );
}
add_action( 'admin_enqueue_scripts', 'cpc_enqueue_admin_assets' );

function cpc_enqueue_styles() {
    wp_enqueue_style( 'cpc-style', plugins_url( 'style.css', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'cpc_enqueue_styles' );

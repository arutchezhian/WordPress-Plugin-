<?php
$role = get_post_meta($post->ID, '_profile_card_role', true);
$email = get_post_meta($post->ID, '_profile_card_email', true);
$bio = get_post_meta($post->ID, '_profile_card_bio', true);
$linkedin = get_post_meta($post->ID, '_profile_card_linkedin', true);
$facebook = get_post_meta($post->ID, '_profile_card_facebook', true);
$instagram = get_post_meta($post->ID, '_profile_card_instagram', true);
$bg_color = get_post_meta($post->ID, '_profile_card_bg_color', true);
$bg_color_style = $bg_color ? "background-color: $bg_color;" : '';
?>

<aside class="profile-card" style="<?php echo esc_attr($bg_color_style); ?>">
    <header>
        <?php if (has_post_thumbnail($post->ID)) : ?>
            <a href="<?php echo esc_url(get_permalink($post->ID)); ?>">
                <?php echo get_the_post_thumbnail($post->ID, 'thumbnail'); ?>
            </a>
        <?php endif; ?>
        <h1><?php echo esc_html(get_the_title($post->ID)); ?></h1>
        <h2><?php echo esc_html($role); ?></h2>
        <h3><?php echo esc_html($email); ?></h3>
    </header>
    <div class="profile-bio">
        <p><?php echo esc_html($bio); ?></p>
    </div>
    <ul class="profile-social-links">
        <?php if ($linkedin) : ?>
            <li><a href="<?php echo esc_url($linkedin); ?>"><img src="https://image.flaticon.com/icons/png/512/174/174857.png" alt="LinkedIn"></a></li>
        <?php endif; ?>
        <?php if ($facebook) : ?>
            <li><a href="<?php echo esc_url($facebook); ?>"><img src="https://image.flaticon.com/icons/png/512/174/174848.png" alt="Facebook"></a></li>
        <?php endif; ?>
        <?php if ($instagram) : ?>
            <li><a href="<?php echo esc_url($instagram); ?>"><img src="https://image.flaticon.com/icons/png/512/174/174855.png" alt="Instagram"></a></li>
        <?php endif; ?>
    </ul>
</aside>

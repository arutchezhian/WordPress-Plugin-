<?php
/*
Plugin Name: Profile Cards
Description: A plugin to create and manage multiple profile cards with customizable images, colors, content, and social media links.
Version: 1.0
Author: Your Name
*/

// Register custom post type for Profile Cards
function create_profile_card_post_type() {
    register_post_type('profile_card',
        array(
            'labels' => array(
                'name' => __('Profile Cards'),
                'singular_name' => __('Profile Card')
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array('title', 'thumbnail'),
            'menu_position' => 5,
            'menu_icon' => 'dashicons-id',
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'create_profile_card_post_type');

// Add custom meta boxes for Profile Cards
function add_profile_card_meta_boxes() {
    add_meta_box('profile_card_meta', 'Profile Card Details', 'profile_card_meta_box_callback', 'profile_card', 'normal', 'high');
}
add_action('add_meta_boxes', 'add_profile_card_meta_boxes');

function profile_card_meta_box_callback($post) {
    wp_nonce_field('save_profile_card_meta', 'profile_card_meta_nonce');

    $role = get_post_meta($post->ID, '_profile_card_role', true);
    $email = get_post_meta($post->ID, '_profile_card_email', true);
    $bio = get_post_meta($post->ID, '_profile_card_bio', true);
    $linkedin = get_post_meta($post->ID, '_profile_card_linkedin', true);
    $facebook = get_post_meta($post->ID, '_profile_card_facebook', true);
    $instagram = get_post_meta($post->ID, '_profile_card_instagram', true);
    $bg_color = get_post_meta($post->ID, '_profile_card_bg_color', true);

    ?>
    <p>
        <label for="profile_card_role">Role/Position:</label>
        <input type="text" id="profile_card_role" name="profile_card_role" value="<?php echo esc_attr($role); ?>" class="widefat">
    </p>
    <p>
        <label for="profile_card_email">Email:</label>
        <input type="email" id="profile_card_email" name="profile_card_email" value="<?php echo esc_attr($email); ?>" class="widefat">
    </p>
    <p>
        <label for="profile_card_bio">Bio:</label>
        <textarea id="profile_card_bio" name="profile_card_bio" class="widefat"><?php echo esc_textarea($bio); ?></textarea>
    </p>
    <p>
        <label for="profile_card_linkedin">LinkedIn URL:</label>
        <input type="url" id="profile_card_linkedin" name="profile_card_linkedin" value="<?php echo esc_attr($linkedin); ?>" class="widefat">
    </p>
    <p>
        <label for="profile_card_facebook">Facebook URL:</label>
        <input type="url" id="profile_card_facebook" name="profile_card_facebook" value="<?php echo esc_attr($facebook); ?>" class="widefat">
    </p>
    <p>
        <label for="profile_card_instagram">Instagram URL:</label>
        <input type="url" id="profile_card_instagram" name="profile_card_instagram" value="<?php echo esc_attr($instagram); ?>" class="widefat">
    </p>
    <p>
        <label for="profile_card_bg_color">Background Color:</label>
        <input type="color" id="profile_card_bg_color" name="profile_card_bg_color" value="<?php echo esc_attr($bg_color ? $bg_color : '#ffffff'); ?>" class="widefat">
    </p>
    <?php
}

function save_profile_card_meta($post_id) {
    if (!isset($_POST['profile_card_meta_nonce']) || !wp_verify_nonce($_POST['profile_card_meta_nonce'], 'save_profile_card_meta')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (isset($_POST['profile_card_role'])) {
        update_post_meta($post_id, '_profile_card_role', sanitize_text_field($_POST['profile_card_role']));
    }
    if (isset($_POST['profile_card_email'])) {
        update_post_meta($post_id, '_profile_card_email', sanitize_email($_POST['profile_card_email']));
    }
    if (isset($_POST['profile_card_bio'])) {
        update_post_meta($post_id, '_profile_card_bio', sanitize_textarea_field($_POST['profile_card_bio']));
    }
    if (isset($_POST['profile_card_linkedin'])) {
        update_post_meta($post_id, '_profile_card_linkedin', esc_url_raw($_POST['profile_card_linkedin']));
    }
    if (isset($_POST['profile_card_facebook'])) {
        update_post_meta($post_id, '_profile_card_facebook', esc_url_raw($_POST['profile_card_facebook']));
    }
    if (isset($_POST['profile_card_instagram'])) {
        update_post_meta($post_id, '_profile_card_instagram', esc_url_raw($_POST['profile_card_instagram']));
    }
    if (isset($_POST['profile_card_bg_color'])) {
        update_post_meta($post_id, '_profile_card_bg_color', sanitize_hex_color($_POST['profile_card_bg_color']));
    }
}
add_action('save_post', 'save_profile_card_meta');

// Enqueue plugin styles
function profile_card_enqueue_styles() {
    wp_enqueue_style('profile-card-style', plugins_url('style.css', __FILE__));
}
add_action('wp_enqueue_scripts', 'profile_card_enqueue_styles');

// Shortcode to display profile cards
function profile_card_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => '',
    ), $atts, 'profile_card');

    $post_id = $atts['id'];
    if (!$post_id) return '';

    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'profile_card') return '';

    ob_start();
    include plugin_dir_path(__FILE__) . 'profile-card-template.php';
    return ob_get_clean();
}
add_shortcode('profile_card', 'profile_card_shortcode');

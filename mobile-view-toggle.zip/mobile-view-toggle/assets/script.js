jQuery(document).ready(function($) {
    $('#mvt-toggle-button').on('click', function() {
        $('body').toggleClass('mvt-mobile-view');

        if ($('body').hasClass('mvt-mobile-view')) {
            $(this).text('Desktop View');
        } else {
            $(this).text('Mobile View');
        }
    });
});

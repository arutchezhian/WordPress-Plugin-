<?php
/**
 * Plugin Name: Mobile View Toggle
 * Description: A plugin to toggle the page view between desktop and mobile versions.
 * Version: 1.0.0
 * Author: Arutchezhian
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Enqueue styles and scripts
function mvt_enqueue_assets() {
    wp_enqueue_style('mvt-style', plugins_url('assets/style.css', __FILE__));
    wp_enqueue_script('mvt-script', plugins_url('assets/script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'mvt_enqueue_assets');

// Add the mobile view toggle button
function mvt_add_mobile_view_button() {
    echo '<button id="mvt-toggle-button" class="mvt-toggle-button">Mobile View</button>';
}
add_action('wp_footer', 'mvt_add_mobile_view_button');
